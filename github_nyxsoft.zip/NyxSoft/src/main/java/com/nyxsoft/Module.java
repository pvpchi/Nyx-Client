package com.nyxsoft;

import com.nyxsoft.settings.Setting;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public String name; public Category category; public boolean enabled; public int key;
    public List<Setting> settings = new ArrayList<>();

    public Module(String name, Category cat, int key) {
        this.name = name; this.category = cat; this.key = key;
    }
    public void toggle() { enabled = !enabled; if (enabled) onEnable(); else onDisable(); }
    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void addSetting(Setting s) { settings.add(s); }
}
