package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.NumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;

public class AimAssist extends Module {
    public NumSetting fov = new NumSetting("FOV", this, 30.0, 5.0, 90.0);
    public NumSetting speed = new NumSetting("Tezlik", this, 0.12, 0.05, 0.5);
    public NumSetting range = new NumSetting("Masofa", this, 4.2, 2.0, 6.0);
    public AimAssist() { super("NishongaYordam", Category.COMBAT, GLFW.GLFW_KEY_I); addSetting(fov); addSetting(speed); addSetting(range); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || !mc.options.attackKey.isPressed()) return;
        LivingEntity target = null; double bestFov = fov.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == mc.player || le.isDead()) continue;
            if (e instanceof PlayerEntity p && (p.isCreative() || p.isSpectator())) continue;
            if (mc.player.distanceTo(e) > range.value) continue;
            Vec3d eye = mc.player.getEyePos(); Vec3d targetPos = e.getBoundingBox().getCenter();
            double dx = targetPos.x - eye.x, dy = targetPos.y - eye.y, dz = targetPos.z - eye.z;
            float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            float yawDiff = Math.abs(MathHelper.wrapDegrees(wantYaw - mc.player.getYaw()));
            float pitchDiff = Math.abs(MathHelper.wrapDegrees(wantPitch - mc.player.getPitch()));
            if (yawDiff < bestFov && pitchDiff < bestFov) { bestFov = yawDiff; target = le; }
        }
        if (target == null) return;
        Vec3d eye = mc.player.getEyePos(); Vec3d aim = target.getBoundingBox().getCenter();
        double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
        float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
        mc.player.setYaw(mc.player.getYaw() + MathHelper.wrapDegrees(wantYaw - mc.player.getYaw()) * (float)speed.value);
        mc.player.setPitch(mc.player.getPitch() + MathHelper.wrapDegrees(wantPitch - mc.player.getPitch()) * (float)speed.value);
    }
}
