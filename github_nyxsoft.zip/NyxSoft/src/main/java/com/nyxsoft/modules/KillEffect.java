package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.BoolSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import org.lwjgl.glfw.GLFW;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class KillEffect extends Module {
    public BoolSetting playSound = new BoolSetting("Tovush", this, true);
    public BoolSetting spawnParticles = new BoolSetting("Portlash", this, true);
    private final Set<UUID> deadEntities = new HashSet<>();
    public KillEffect() { super("KillEffect", Category.RENDER, GLFW.GLFW_KEY_L); addSetting(playSound); addSetting(spawnParticles); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.world == null || mc.player == null) return;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity le && le != mc.player) {
                if ((le.isDead() || le.getHealth() <= 0) && !deadEntities.contains(le.getUuid())) {
                    deadEntities.add(le.getUuid());
                    if (mc.player.distanceTo(le) <= 10.0) {
                        if (playSound.enabled) mc.world.playSound(mc.player, le.getBlockPos(), SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, SoundCategory.PLAYERS, 0.5f, 1.0f);
                        if (spawnParticles.enabled) for (int i = 0; i < 10; i++) mc.world.addParticle(ParticleTypes.EXPLOSION, le.getX(), le.getY() + 1, le.getZ(), 0, 0, 0);
                    }
                }
            }
        }
    }
    @Override public void onDisable() { deadEntities.clear(); }
}
