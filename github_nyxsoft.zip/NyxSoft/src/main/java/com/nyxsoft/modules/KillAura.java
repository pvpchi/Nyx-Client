package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.*;
import org.lwjgl.glfw.GLFW;

public class KillAura extends Module {
    public NumSetting range = new NumSetting("Masofa", this, 3.0, 1.0, 6.0);
    public NumSetting cps = new NumSetting("CPS", this, 8.0, 1.0, 20.0);
    public NumSetting rotateSpeed = new NumSetting("Burilish", this, 0.2, 0.05, 1.0);
    public BoolSetting autoBlock = new BoolSetting("Qalqon", this, false);
    private int cooldown = 0;
    public KillAura() { super("AvtoUrish", Category.COMBAT, GLFW.GLFW_KEY_K); addSetting(range); addSetting(cps); addSetting(rotateSpeed); addSetting(autoBlock); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || cooldown-- > 0) return;
        LivingEntity target = null; double bestDist = range.value;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == mc.player || le.isDead()) continue;
            if (e instanceof PlayerEntity p && (p.isCreative() || p.isSpectator())) continue;
            double d = mc.player.distanceTo(e); if (d < bestDist) { bestDist = d; target = le; }
        }
        if (target != null) {
            Vec3d eye = mc.player.getEyePos(); Vec3d aim = target.getBoundingBox().getCenter();
            double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
            float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));
            float speed = (float) rotateSpeed.value;
            mc.player.setYaw(mc.player.getYaw() + MathHelper.wrapDegrees(wantYaw - mc.player.getYaw()) * speed);
            mc.player.setPitch(mc.player.getPitch() + MathHelper.wrapDegrees(wantPitch - mc.player.getPitch()) * speed);
            if (autoBlock.enabled && mc.player.getOffHandStack().getItem().toString().contains("shield")) mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            mc.interactionManager.attackEntity(mc.player, target); mc.player.swingHand(Hand.MAIN_HAND);
            cooldown = (int) (20 / cps.value);
        }
    }
}
