package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.util.FriendManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
public class PlayerESP extends Module {
    public PlayerESP() { super("O'yinchiESP", Category.RENDER, GLFW.GLFW_KEY_P); }
    public void render(MatrixStack m, VertexConsumerProvider.Immediate vcp) {
        if (!enabled) return; MinecraftClient mc = MinecraftClient.getInstance(); if (mc.world == null || mc.player == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Box box = p.getBoundingBox().offset(-cam.x, -cam.y, -cam.z);
            if (FriendManager.isFriend(p.getName().getString())) net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), box, 0f, 1f, 0f, 1f);
            else net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), box, 1f, 0.3f, 0.3f, 1f);
        }
    }
}
