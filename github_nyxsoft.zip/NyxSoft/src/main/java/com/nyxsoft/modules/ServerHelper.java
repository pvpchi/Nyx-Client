package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
public class ServerHelper extends Module {
    private int timer = 0;
    public ServerHelper() { super("ServerYordam", Category.MISC, GLFW.GLFW_KEY_R); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player == null) return;
        if (++timer >= 600) { if (mc.currentScreen == null) mc.player.jump(); timer = 0; }
    }
}
