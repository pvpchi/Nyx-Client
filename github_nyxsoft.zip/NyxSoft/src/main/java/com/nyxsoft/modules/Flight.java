package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
public class Flight extends Module {
    public Flight() { super("Uchish", Category.MOVEMENT, GLFW.GLFW_KEY_F); }
    @Override public void onEnable() { MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player != null) { mc.player.getAbilities().allowFlying = true; mc.player.getAbilities().flying = true; } }
    @Override public void onDisable() { MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player != null && !mc.player.isCreative()) { mc.player.getAbilities().allowFlying = false; mc.player.getAbilities().flying = false; } }
}
