package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
public class MaceHelper extends Module {
    public MaceHelper() { super("MaceYordam", Category.COMBAT, GLFW.GLFW_KEY_M); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.getMainHandStack().isOf(Items.MACE) && mc.player.fallDistance > 1.5f && mc.player.getVelocity().y < -0.1 && mc.options.attackKey.isPressed()) {
            mc.interactionManager.attackEntity(mc.player, mc.crosshairTarget instanceof net.minecraft.util.hit.EntityHitResult hit ? hit.getEntity() : null);
        }
    }
}
