package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.*;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
public class Bot extends Module {
    public Bot() { super("Bot", Category.MISC, GLFW.GLFW_KEY_B); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player == null || mc.world == null) return;
        mc.options.forwardKey.setPressed(true);
        mc.options.jumpKey.setPressed(mc.player.horizontalCollision);
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity le && le != mc.player && !le.isDead() && mc.player.distanceTo(le) <= 3.2) {
                mc.interactionManager.attackEntity(mc.player, le); mc.player.swingHand(Hand.MAIN_HAND); break;
            }
        }
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.options != null) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); }
    }
}
