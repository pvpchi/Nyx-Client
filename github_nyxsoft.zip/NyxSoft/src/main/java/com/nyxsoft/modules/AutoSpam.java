package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.NumSetting;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
public class AutoSpam extends Module {
    public String message = "NyxSoft on top!";
    public NumSetting delay = new NumSetting("Delay", this, 100.0, 20.0, 200.0);
    private int timer = 0;
    public AutoSpam() { super("AvtoSpam", Category.MISC, GLFW.GLFW_KEY_V); addSetting(delay); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player == null || mc.player.networkHandler == null) return;
        if (++timer >= delay.value) { mc.player.networkHandler.sendChatMessage(message); timer = 0; }
    }
}
