package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
public class DeathCoords extends Module {
    private boolean dead = false;
    public DeathCoords() { super("O'limJoyi", Category.RENDER, GLFW.GLFW_KEY_Z); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.player == null) return;
        if (mc.player.getHealth() <= 0 && !dead) { dead = true; mc.player.sendMessage(Text.literal("§c[Nyx] O'lim joyi: " + (int) mc.player.getX() + ", " + (int) mc.player.getY() + ", " + (int) mc.player.getZ()), false); }
        else if (mc.player.getHealth() > 0) dead = false;
    }
}
