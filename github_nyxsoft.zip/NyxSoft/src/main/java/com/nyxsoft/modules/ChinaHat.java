package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
public class ChinaHat extends Module {
    public ChinaHat() { super("XitoyShlyapasi", Category.RENDER, GLFW.GLFW_KEY_C); }
    public void render(MatrixStack m, VertexConsumerProvider.Immediate vcp) {
        if (!enabled) return; MinecraftClient mc = MinecraftClient.getInstance(); if (mc.world == null || mc.player == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Vec3d pos = p.getPos().add(0, p.getHeight() + 0.2, 0).subtract(cam);
            Box hatBox = new Box(pos.x - 0.25, pos.y, pos.z - 0.25, pos.x + 0.25, pos.y + 0.1, pos.z + 0.25);
            net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), hatBox, 1f, 0.5f, 0f, 1f);
        }
    }
}
