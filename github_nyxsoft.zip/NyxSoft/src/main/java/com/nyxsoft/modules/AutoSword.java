package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.SwordItem;
import org.lwjgl.glfw.GLFW;
public class AutoSword extends Module {
    public AutoSword() { super("AvtoQilich", Category.COMBAT, GLFW.GLFW_KEY_X); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.options.attackKey.isPressed()) {
            for (int i = 0; i < 9; i++) { if (mc.player.getInventory().getStack(i).getItem() instanceof SwordItem) { mc.player.getInventory().selectedSlot = i; break; } }
        }
    }
}
