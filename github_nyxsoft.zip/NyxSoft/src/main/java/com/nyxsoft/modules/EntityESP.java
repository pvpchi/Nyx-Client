package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
public class EntityESP extends Module {
    public EntityESP() { super("MavjudotESP", Category.RENDER, GLFW.GLFW_KEY_U); }
    public void render(MatrixStack m, VertexConsumerProvider.Immediate vcp) {
        if (!enabled) return; MinecraftClient mc = MinecraftClient.getInstance(); if (mc.world == null || mc.player == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof ItemEntity || e instanceof HostileEntity)) continue;
            Box box = e.getBoundingBox().offset(-cam.x, -cam.y, -cam.z);
            net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), box, 1f, 1f, 0.3f, 1f);
        }
    }
}
