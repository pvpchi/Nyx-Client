package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import org.lwjgl.glfw.GLFW;
public class NoSlow extends Module { public NoSlow() { super("Sekinlashmaslik", Category.MOVEMENT, GLFW.GLFW_KEY_N); } }
