package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import org.lwjgl.glfw.GLFW;
public class Interface extends Module {
    public Interface() { super("Interface", Category.MISC, GLFW.GLFW_KEY_H); this.enabled = true; }
}
