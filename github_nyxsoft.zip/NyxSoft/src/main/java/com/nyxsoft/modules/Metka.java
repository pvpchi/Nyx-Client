package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.util.MetkaManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
public class Metka extends Module {
    public Metka() { super("Metka", Category.RENDER, GLFW.GLFW_KEY_H); }
    public void render(MatrixStack m, VertexConsumerProvider.Immediate vcp) {
        if (!enabled) return; MinecraftClient mc = MinecraftClient.getInstance(); if (mc.world == null || mc.player == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        for (MetkaManager.MetkaData mt : MetkaManager.metkalar) {
            double dx = mt.x - cam.x, dy = mt.y - cam.y, dz = mt.z - cam.z;
            Box box = new Box(dx - 0.5, dy, dz - 0.5, dx + 0.5, dy + 1.0, dz + 0.5);
            net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), box, 1f, 0.5f, 0f, 1f);
            Box pillar = new Box(dx - 0.05, dy + 1.0, dz - 0.05, dx + 0.05, dy + 50.0, dz + 0.05);
            net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), pillar, 1f, 0.5f, 0f, 0.5f);
        }
    }
}
