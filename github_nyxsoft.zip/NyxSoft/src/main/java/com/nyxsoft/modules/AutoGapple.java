package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.NumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;
public class AutoGapple extends Module {
    public NumSetting health = new NumSetting("Jon", this, 15.0, 1.0, 20.0);
    public AutoGapple() { super("AvtoOlma", Category.COMBAT, GLFW.GLFW_KEY_G); addSetting(health); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.getHealth() <= health.value) {
            if (mc.player.getMainHandStack().isOf(Items.ENCHANTED_GOLDEN_APPLE) || mc.player.getMainHandStack().isOf(Items.GOLDEN_APPLE)) mc.options.useKey.setPressed(true);
        }
    }
}
