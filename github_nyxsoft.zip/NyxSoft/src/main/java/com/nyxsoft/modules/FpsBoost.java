package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.*;
import org.lwjgl.glfw.GLFW;
public class FpsBoost extends Module {
    public ModeSetting mode = new ModeSetting("Rejim", this, new String[]{"Oson", "O'rtacha", "Qiyin"}, 1);
    public FpsBoost() { super("FPSOshirish", Category.RENDER, GLFW.GLFW_KEY_B); addSetting(mode); }
    @Override public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.options == null) return;
        if (mode.getMode().equals("Oson")) { mc.options.getRenderDistance().setValue(10); mc.options.getParticles().setValue(ParticlesMode.DECREASED); mc.options.getGraphicsMode().setValue(GraphicsMode.FANCY); }
        else if (mode.getMode().equals("O'rtacha")) { mc.options.getRenderDistance().setValue(8); mc.options.getParticles().setValue(ParticlesMode.MINIMAL); mc.options.getGraphicsMode().setValue(GraphicsMode.FAST); mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF); }
        else { mc.options.getRenderDistance().setValue(4); mc.options.getParticles().setValue(ParticlesMode.MINIMAL); mc.options.getGraphicsMode().setValue(GraphicsMode.FAST); mc.options.getEntityShadows().setValue(false); mc.options.getCloudRenderMode().setValue(CloudRenderMode.OFF); }
    }
    @Override public void onDisable() {
        MinecraftClient mc = MinecraftClient.getInstance(); if (mc.options == null) return;
        mc.options.getRenderDistance().setValue(12); mc.options.getParticles().setValue(ParticlesMode.ALL); mc.options.getGraphicsMode().setValue(GraphicsMode.FANCY); mc.options.getEntityShadows().setValue(true); mc.options.getCloudRenderMode().setValue(CloudRenderMode.FANCY);
    }
}
