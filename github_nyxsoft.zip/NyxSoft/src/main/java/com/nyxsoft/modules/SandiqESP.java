package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.glfw.GLFW;
public class SandiqESP extends Module {
    public SandiqESP() { super("SandiqESP", Category.RENDER, GLFW.GLFW_KEY_O); }
    public void render(MatrixStack m, VertexConsumerProvider.Immediate vcp) {
        if (!enabled) return; MinecraftClient mc = MinecraftClient.getInstance(); if (mc.world == null || mc.player == null) return;
        Vec3d cam = mc.gameRenderer.getCamera().getPos(); int rd = mc.options.getViewDistance().getValue();
        int pX = mc.player.getChunkPos().x, pZ = mc.player.getChunkPos().z;
        for (int x = pX - rd; x <= pX + rd; x++) {
            for (int z = pZ - rd; z <= pZ + rd; z++) {
                WorldChunk chunk = mc.world.getChunk(x, z); if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    Box box = null; float r = 1f, g = 1f, b = 0f;
                    if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity) {
                        box = new Box(be.getPos()).offset(-cam.x, -cam.y, -cam.z).expand(0.1);
                    } else if (be instanceof MobSpawnerBlockEntity) {
                        box = new Box(be.getPos()).offset(-cam.x, -cam.y, -cam.z).expand(0.1); r = 1f; g = 0f; b = 0f;
                    }
                    if (box != null) net.minecraft.client.render.WorldRenderer.drawBox(m, vcp.getBuffer(RenderLayer.getLines()), box, r, g, b, 1f);
                }
            }
        }
    }
}
