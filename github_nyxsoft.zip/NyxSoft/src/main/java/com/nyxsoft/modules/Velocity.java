package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.NumSetting;
import org.lwjgl.glfw.GLFW;
public class Velocity extends Module {
    public NumSetting horizontal = new NumSetting("Gorizontal", this, 0.6, 0.0, 1.0);
    public NumSetting vertical = new NumSetting("Vertikal", this, 0.6, 0.0, 1.0);
    public Velocity() { super("OrqagaKetish", Category.COMBAT, GLFW.GLFW_KEY_V); addSetting(horizontal); addSetting(vertical); }
}
