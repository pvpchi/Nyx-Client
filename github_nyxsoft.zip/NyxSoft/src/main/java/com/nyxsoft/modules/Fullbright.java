package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
public class Fullbright extends Module {
    private double old = 1.0;
    public Fullbright() { super("Yorug'lik", Category.RENDER, GLFW.GLFW_KEY_0); }
    @Override public void onEnable() { MinecraftClient mc = MinecraftClient.getInstance(); if (mc.options != null) old = mc.options.getGamma().getValue(); }
    @Override public void onTick() { MinecraftClient mc = MinecraftClient.getInstance(); if (mc.options != null) mc.options.getGamma().setValue(10.0); }
    @Override public void onDisable() { MinecraftClient mc = MinecraftClient.getInstance(); if (mc.options != null) mc.options.getGamma().setValue(old); }
}
