package com.nyxsoft.modules;
import com.nyxsoft.Category;
import com.nyxsoft.Module;
import com.nyxsoft.settings.NumSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;
public class TriggerBot extends Module {
    public NumSetting delay = new NumSetting("Delay", this, 5.0, 0.0, 20.0);
    private int cd = 0;
    public TriggerBot() { super("AvtoKlik", Category.COMBAT, GLFW.GLFW_KEY_T); addSetting(delay); }
    @Override public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.crosshairTarget == null || cd-- > 0) return;
        if (mc.crosshairTarget instanceof EntityHitResult h && h.getEntity() instanceof LivingEntity le && le != mc.player && mc.player.distanceTo(le) <= 3.0) {
            mc.interactionManager.attackEntity(mc.player, le); mc.player.swingHand(Hand.MAIN_HAND); cd = (int) delay.value;
        }
    }
}
