package com.nyxsoft;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class WelcomeScreen extends Screen {
    public WelcomeScreen() { super(Text.literal("Xush kelibsiz!")); }
    @Override protected void init() {
        this.addDrawableChild(ButtonWidget.builder(Text.literal("O'yinni boshlash"), (b) -> this.close()).dimensions(this.width / 2 - 100, this.height / 2 + 20, 200, 20).build());
    }
    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.renderBackground(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "§6NyxSoft §fClient'ga Xush kelibsiz!", this.width / 2, this.height / 2 - 40, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "§7RightShift tugmasi orqali menyuni oching", this.width / 2, this.height / 2 - 20, 0xAAAAAA);
        super.render(ctx, mouseX, mouseY, delta);
    }
    @Override public boolean shouldPause() { return false; }
}
