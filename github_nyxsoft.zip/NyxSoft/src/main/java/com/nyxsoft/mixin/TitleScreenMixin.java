package com.nyxsoft.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public class TitleScreenMixin extends Screen {
    protected TitleScreenMixin(Text title) { super(title); }

    @Inject(method = "init", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        this.clearChildren();
        int centerX = this.width / 2; int startY = this.height / 2 - 20;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§6Yakka O'yin"), (b) -> this.client.setScreen(new SelectWorldScreen(this))).dimensions(centerX - 100, startY, 200, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§6Ko'p O'yinchi"), (b) -> this.client.setScreen(new MultiplayerScreen(this))).dimensions(centerX - 100, startY + 24, 200, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§6Sozlamalar"), (b) -> this.client.setScreen(new net.minecraft.client.gui.screen.option.OptionsScreen(this, this.client.options))).dimensions(centerX - 100, startY + 48, 200, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("§cChiqish"), (b) -> this.client.scheduleStop()).dimensions(centerX - 100, startY + 72, 200, 20).build());
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        Identifier bgTexture = new Identifier("nyxsoft", "textures/gui/background.png");
        try { ctx.drawTexture(bgTexture, 0, 0, 0, 0, this.width, this.height, this.width, this.height); }
        catch (Exception e) { ctx.fill(0, 0, this.width, this.height, 0xEE111111); }
        ctx.drawCenteredTextWithShadow(this.textRenderer, "§6NyxSoft §fLauncher", this.width / 2, this.height / 2 - 60, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(this.textRenderer, "§7RightShift - Cheat Menyusi", this.width / 2, this.height - 30, 0xAAAAAA);
        super.render(ctx, mouseX, mouseY, delta);
    }
}
