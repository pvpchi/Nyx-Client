package com.nyxsoft.mixin;

import com.nyxsoft.NyxSoft;
import com.nyxsoft.modules.Velocity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import org.spongepowered.asm.mixin.injection.Inject;

@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
    @ModifyArgs(method = "setVelocityClient", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;setVelocity(DDD)V"))
    private void onSetVel(Args args) {
        var v = NyxSoft.modules.get("Velocity");
        if (v != null && v.enabled) {
            Velocity vel = (Velocity) v;
            args.set(0, (double) args.get(0) * vel.horizontal.value);
            args.set(1, (double) args.get(1) * vel.vertical.value);
            args.set(2, (double) args.get(2) * vel.horizontal.value);
        }
    }

    @Inject(method = "isUsingItem", at = @At("HEAD"), cancellable = true)
    private void onIsUsingItem(CallbackInfoReturnable<Boolean> cir) {
        var ns = NyxSoft.modules.get("NoSlow");
        if (ns != null && ns.enabled) cir.setReturnValue(false);
    }
}
