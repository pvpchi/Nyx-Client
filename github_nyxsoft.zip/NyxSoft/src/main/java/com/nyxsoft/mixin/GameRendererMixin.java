package com.nyxsoft.mixin;

import com.nyxsoft.NyxSoft;
import com.nyxsoft.modules.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSystem;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "renderWorld", at = @At("TAIL"))
    private void onRenderWorld(float td, long lt, MatrixStack m, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var vcp = mc.getBufferBuilders().getEntityVertexConsumers();
        RenderSystem.disableDepthTest();
        for (var mod : NyxSoft.modules.list) {
            if (!mod.enabled) continue;
            if (mod instanceof PlayerESP p) p.render(m, vcp);
            if (mod instanceof EntityESP e) e.render(m, vcp);
            if (mod instanceof WardenESP w) w.render(m, vcp);
            if (mod instanceof ChinaHat c) c.render(m, vcp);
            if (mod instanceof SandiqESP s) s.render(m, vcp);
            if (mod instanceof Metka mt) mt.render(m, vcp);
        }
        vcp.draw(RenderLayer.getLines());
        RenderSystem.enableDepthTest();
    }
}
