package com.nyxsoft;
public enum Category { COMBAT, MOVEMENT, RENDER, PLAYER, MISC }
