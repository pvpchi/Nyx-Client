package com.nyxsoft.util;

import com.nyxsoft.NyxSoft;
import com.nyxsoft.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public class CommandManager {
    public static void handle(String message) {
        if (!message.startsWith(".")) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        String[] args = message.substring(1).split(" ");
        if (args.length == 0) return;
        String cmd = args[0].toLowerCase();

        if (cmd.equals("friend")) {
            if (args.length < 3) { mc.player.sendMessage(Text.literal("§c.friend add/remove <ism>"), false); return; }
            if (args[1].equalsIgnoreCase("add")) { FriendManager.add(args[2]); mc.player.sendMessage(Text.literal("§a[Friend] Qo'shildi"), false); }
            else if (args[1].equalsIgnoreCase("remove")) { FriendManager.remove(args[2]); mc.player.sendMessage(Text.literal("§c[Friend] O'chirildi"), false); }
        }
        else if (cmd.equals("bind")) {
            if (args.length < 3) { mc.player.sendMessage(Text.literal("§c.bind <modul> <tugma>"), false); return; }
            Module m = NyxSoft.modules.get(args[1]);
            if (m != null && !args[2].isEmpty()) { m.key = args[2].toUpperCase().charAt(0); mc.player.sendMessage(Text.literal("§a[Bind] Bog'landi"), false); }
        }
        else if (cmd.equals("config") || cmd.equals("cfg")) {
            if (args.length > 1 && args[1].equalsIgnoreCase("save")) { ConfigManager.save(); mc.player.sendMessage(Text.literal("§a[Config] Saklandi"), false); }
            else { ConfigManager.load(); mc.player.sendMessage(Text.literal("§a[Config] Yuklandi"), false); }
        }
        else if (cmd.equals("metka")) {
            if (args.length < 2) return;
            if (args[1].equalsIgnoreCase("add")) {
                if (args.length >= 6) { MetkaManager.add(args[2], Double.parseDouble(args[3]), Double.parseDouble(args[4]), Double.parseDouble(args[5])); }
                else if (args.length == 3) { MetkaManager.add(args[2], mc.player.getX(), mc.player.getY(), mc.player.getZ()); }
            } else if (args[1].equalsIgnoreCase("clear")) { MetkaManager.clear(); }
        }
    }
}
