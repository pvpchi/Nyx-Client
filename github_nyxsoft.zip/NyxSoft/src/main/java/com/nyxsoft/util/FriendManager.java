package com.nyxsoft.util;
import java.util.HashSet;
import java.util.Set;
public class FriendManager {
    public static final Set<String> friends = new HashSet<>();
    public static boolean isFriend(String name) { return friends.contains(name.toLowerCase()); }
    public static void add(String name) { friends.add(name.toLowerCase()); }
    public static void remove(String name) { friends.remove(name.toLowerCase()); }
}
