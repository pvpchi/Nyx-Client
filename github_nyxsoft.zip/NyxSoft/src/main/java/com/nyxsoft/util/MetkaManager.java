package com.nyxsoft.util;
import java.util.ArrayList;
import java.util.List;
public class MetkaManager {
    public static class MetkaData {
        public String name; public double x, y, z;
        public MetkaData(String name, double x, double y, double z) {
            this.name = name; this.x = x; this.y = y; this.z = z;
        }
    }
    public static final List<MetkaData> metkalar = new ArrayList<>();
    public static void add(String name, double x, double y, double z) { metkalar.add(new MetkaData(name, x, y, z)); }
    public static void clear() { metkalar.clear(); }
}
