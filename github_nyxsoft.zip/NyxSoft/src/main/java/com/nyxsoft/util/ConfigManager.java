package com.nyxsoft.util;

import com.nyxsoft.NyxSoft;
import com.nyxsoft.Module;
import com.nyxsoft.settings.*;
import java.io.File;
import java.io.PrintWriter;
import java.util.Scanner;

public class ConfigManager {
    private static final File file = new File("nyxsoft_config.txt");
    public static void save() {
        try (PrintWriter pw = new PrintWriter(file)) {
            for (Module m : NyxSoft.modules.list) {
                pw.println("MOD:" + m.name + ":" + m.enabled);
                for (Setting s : m.settings) {
                    if (s instanceof NumSetting ns) pw.println("NUM:" + m.name + ":" + s.name + ":" + ns.value);
                    else if (s instanceof BoolSetting bs) pw.println("BOOL:" + m.name + ":" + s.name + ":" + bs.enabled);
                    else if (s instanceof ModeSetting ms) pw.println("MODE:" + m.name + ":" + s.name + ":" + ms.index);
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void load() {
        if (!file.exists()) return;
        try (Scanner sc = new Scanner(file)) {
            while (sc.hasNextLine()) {
                String[] p = sc.nextLine().split(":");
                if (p.length >= 3) {
                    Module m = NyxSoft.modules.get(p[1]);
                    if (m == null) continue;
                    if (p[0].equals("MOD")) m.enabled = Boolean.parseBoolean(p[2]);
                    else {
                        for (Setting s : m.settings) {
                            if (s.name.equals(p[2])) {
                                if (p[0].equals("NUM") && s instanceof NumSetting ns) ns.value = Double.parseDouble(p[3]);
                                else if (p[0].equals("BOOL") && s instanceof BoolSetting bs) bs.enabled = Boolean.parseBoolean(p[3]);
                                else if (p[0].equals("MODE") && s instanceof ModeSetting ms) ms.index = Integer.parseInt(p[3]);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
    }
}
