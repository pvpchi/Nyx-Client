package com.nyxsoft;

import com.nyxsoft.settings.*;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class Gui extends Screen {
    private Module openModule = null;
    private Setting draggingSetting = null;
    private int lastSliderX = -1;
    private final int panelWidth = 110, panelGap = 5;

    public Gui() { super(Text.literal("NyxSoft Menyusi")); }
    @Override public boolean shouldPause() { return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float d) {
        ctx.fill(0, 0, width, height, 0x99000000);
        int btnW = 120; int btnX = width / 2 - btnW / 2;
        ctx.fill(btnX, 10, btnX + btnW, 28, Theme.bg);
        ctx.fill(btnX, 10, btnX + 2, 28, Theme.accent);
        ctx.drawText(textRenderer, "Rangni almashtirish", btnX + 6, 15, Theme.text, false);

        Category[] cats = Category.values();
        int totalWidth = (cats.length * panelWidth) + ((cats.length - 1) * panelGap);
        int startX = width / 2 - totalWidth / 2;
        int startY = 40;

        for (int i = 0; i < cats.length; i++) {
            Category cat = cats[i];
            int x = startX + (i * (panelWidth + panelGap));
            ctx.fill(x, startY, x + panelWidth, startY + 16, Theme.accent);
            ctx.drawCenteredTextWithShadow(textRenderer, cat.name(), x + panelWidth / 2, startY + 4, 0xFFFFFF);

            int currentY = startY + 18;
            for (Module m : NyxSoft.modules.list) {
                if (m.category != cat) continue;
                boolean hover = mx >= x && mx <= x + panelWidth && my >= currentY && my <= currentY + 14;
                int bgCol = m.enabled ? Theme.accent : (hover ? 0xFF333333 : Theme.bg);
                ctx.fill(x, currentY, x + panelWidth, currentY + 14, bgCol);
                ctx.drawText(textRenderer, m.name, x + 4, currentY + 3, 0xFFFFFF, false);

                String key = GLFW.glfwGetKeyName(m.key, 0);
                if (key != null) ctx.drawText(textRenderer, "[" + key.toUpperCase() + "]", x + panelWidth - 18, currentY + 3, 0xFFAAAAAA, false);
                currentY += 15;

                if (openModule == m && !m.settings.isEmpty()) {
                    for (Setting s : m.settings) {
                        ctx.fill(x, currentY, x + panelWidth, currentY + 12, 0xFF1A1A1A);
                        if (s instanceof NumSetting ns) {
                            ctx.drawText(textRenderer, s.name + ": " + String.format("%.1f", ns.value), x + 4, currentY + 2, 0xFFDDDDDD, false);
                            ctx.fill(x + 4, currentY + 10, x + panelWidth - 4, currentY + 11, 0xFF444444);
                            float percent = (float) ((ns.value - ns.min) / (ns.max - ns.min));
                            ctx.fill(x + 4, currentY + 10, x + 4 + (int)((panelWidth - 8) * percent), currentY + 11, Theme.accent);
                        } else if (s instanceof BoolSetting bs) {
                            ctx.drawText(textRenderer, s.name + ": " + (bs.enabled ? "§aON" : "§cOFF"), x + 4, currentY + 2, 0xFFDDDDDD, false);
                        } else if (s instanceof ModeSetting ms) {
                            ctx.drawText(textRenderer, s.name + ": §e" + ms.getMode(), x + 4, currentY + 2, 0xFFDDDDDD, false);
                        }
                        currentY += 13;
                    }
                }
            }
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (mx >= width / 2 - 60 && mx <= width / 2 + 60 && my >= 10 && my <= 28) { Theme.cycleColor(); return true; }
        Category[] cats = Category.values();
        int totalWidth = (cats.length * panelWidth) + ((cats.length - 1) * panelGap);
        int startX = width / 2 - totalWidth / 2;
        int startY = 40;

        for (int i = 0; i < cats.length; i++) {
            int x = startX + (i * (panelWidth + panelGap));
            int currentY = startY + 18;
            for (Module m : NyxSoft.modules.list) {
                if (m.category != cats[i]) continue;
                if (mx >= x && mx <= x + panelWidth && my >= currentY && my <= currentY + 14) {
                    if (openModule == m) m.toggle();
                    else openModule = m;
                    return true;
                }
                currentY += 15;

                if (openModule == m && !m.settings.isEmpty()) {
                    for (Setting s : m.settings) {
                        if (mx >= x && mx <= x + panelWidth && my >= currentY && my <= currentY + 12) {
                            if (s instanceof BoolSetting bs) bs.enabled = !bs.enabled;
                            else if (s instanceof ModeSetting ms) ms.cycle();
                            else if (s instanceof NumSetting ns) {
                                lastSliderX = x; draggingSetting = s;
                                float percent = (float) Math.max(0, Math.min(1, (mx - (x + 4)) / (panelWidth - 8)));
                                ns.setValue(ns.min + ((ns.max - ns.min) * percent));
                            }
                            return true;
                        }
                        currentY += 13;
                    }
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingSetting instanceof NumSetting ns && lastSliderX != -1) {
            float percent = (float) Math.max(0, Math.min(1, (mx - (lastSliderX + 4)) / (panelWidth - 8)));
            ns.setValue(ns.min + ((ns.max - ns.min) * percent));
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        draggingSetting = null; lastSliderX = -1;
        return super.mouseReleased(mx, my, button);
    }
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
