package com.nyxsoft;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.hit.EntityHitResult;
import java.util.Collection;

public class HudRenderer {
    private static final int NEON_BLUE = 0xFF00E5FF;
    private static final int BG_COLOR = 0x90000000;

    public static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;

        Module iface = NyxSoft.modules.get("Interface");
        if (iface == null || !iface.enabled) return;

        int screenW = ctx.getScaledWindowWidth(); int screenH = ctx.getScaledWindowHeight();

        String watermarkText = "NyxSoft | " + mc.getCurrentFps() + " FPS";
        int wmWidth = mc.textRenderer.getWidth(watermarkText) + 16;
        ctx.fill(screenW / 2 - wmWidth / 2, 4, screenW / 2 + wmWidth / 2, 18, BG_COLOR);
        ctx.fill(screenW / 2 - wmWidth / 2, 18, screenW / 2 + wmWidth / 2, 19, NEON_BLUE);
        ctx.drawCenteredTextWithShadow(mc.textRenderer, watermarkText, screenW / 2, 7, NEON_BLUE);

        if (mc.crosshairTarget instanceof EntityHitResult hit && hit.getEntity() instanceof LivingEntity target) {
            int thW = 130, thH = 42, thX = screenW / 2 - thW / 2, thY = screenH / 2 + 20;
            ctx.fill(thX, thY, thX + thW, thY + thH, BG_COLOR);
            ctx.fill(thX, thY, thX + thW, thY + 2, NEON_BLUE);
            ctx.drawText(mc.textRenderer, target.getName().getString(), thX + 6, thY + 6, 0xFFFFFFFF, true);
            if (target instanceof PlayerEntity p && mc.getNetworkHandler() != null) {
                var entry = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
                if (entry != null) ctx.drawText(mc.textRenderer, entry.getLatency() + "ms", thX + thW - 30, thY + 6, 0xFFAAAAAA, false);
            }
            float hpPercent = Math.max(0, target.getHealth() / target.getMaxHealth());
            ctx.fill(thX + 6, thY + 22, thX + thW - 6, thY + 30, 0xFF333333);
            ctx.fill(thX + 6, thY + 22, thX + 6 + (int)((thW - 12) * hpPercent), thY + 30, 0xFF00FF00);
            ctx.drawText(mc.textRenderer, (int)target.getHealth() + " ❤", thX + 6, thY + 32, 0xFFFFFFFF, false);
        }

        Collection<StatusEffectInstance> effects = mc.player.getStatusEffects();
        int potionY = 30;
        for (StatusEffectInstance effect : effects) {
            String text = effect.getEffectType().value().getName().getString() + " " + String.format("%d:%02d", (effect.getDuration()/20) / 60, (effect.getDuration()/20) % 60);
            int potW = mc.textRenderer.getWidth(text) + 12;
            ctx.fill(screenW - potW - 4, potionY, screenW - 4, potionY + 14, BG_COLOR);
            ctx.fill(screenW - potW - 4, potionY, screenW - 2, potionY + 14, NEON_BLUE);
            ctx.drawText(mc.textRenderer, text, screenW - potW + 2, potionY + 3, 0xFFFFFFFF, false);
            potionY += 16;
        }

        int modY = 30;
        for (Module m : NyxSoft.modules.list) {
            if (!m.enabled || m.name.equals("Interface")) continue;
            int modW = mc.textRenderer.getWidth(m.name) + 12;
            ctx.fill(4, modY, 4 + modW, modY + 14, BG_COLOR);
            ctx.fill(4, modY, 6, modY + 14, NEON_BLUE);
            ctx.drawText(mc.textRenderer, m.name, 8, modY + 3, 0xFFFFFFFF, false);
            modY += 16;
        }
    }
}
