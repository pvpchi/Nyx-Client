package com.nyxsoft;

public class Theme {
    public static int accent = 0xFFFF8C00;
    public static int bg = 0xEE111111;
    public static int moduleBg = 0xFF222222;
    public static int text = 0xFFFFFFFF;
    public static int textDim = 0xFFAAAAAA;

    public static void cycleColor() {
        if (accent == 0xFFFF8C00) accent = 0xFF9B59B6;
        else if (accent == 0xFF9B59B6) accent = 0xFFE74C3C;
        else if (accent == 0xFFE74C3C) accent = 0xFF2ECC71;
        else if (accent == 0xFF2ECC71) accent = 0xFF3498DB;
        else accent = 0xFFFF8C00;
    }
}
