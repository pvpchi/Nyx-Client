package com.nyxsoft.settings;
import com.nyxsoft.Module;
public abstract class Setting {
    public String name; public Module parent;
    public Setting(String name, Module parent) { this.name = name; this.parent = parent; }
}
