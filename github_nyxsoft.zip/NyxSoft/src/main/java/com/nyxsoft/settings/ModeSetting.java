package com.nyxsoft.settings;
import com.nyxsoft.Module;
public class ModeSetting extends Setting {
    public String[] modes; public int index;
    public ModeSetting(String name, Module parent, String[] modes, int defaultIndex) {
        super(name, parent); this.modes = modes; this.index = defaultIndex;
    }
    public String getMode() { return modes[index]; }
    public void cycle() { index = (index + 1) % modes.length; }
}
