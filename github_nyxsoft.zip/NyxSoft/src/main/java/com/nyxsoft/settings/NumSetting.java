package com.nyxsoft.settings;
import com.nyxsoft.Module;
public class NumSetting extends Setting {
    public double value, min, max;
    public NumSetting(String name, Module parent, double defaultVal, double min, double max) {
        super(name, parent); this.value = defaultVal; this.min = min; this.max = max;
    }
    public void setValue(double val) { this.value = Math.max(min, Math.min(max, val)); }
}
