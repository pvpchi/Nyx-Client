package com.nyxsoft.settings;
import com.nyxsoft.Module;
public class BoolSetting extends Setting {
    public boolean enabled;
    public BoolSetting(String name, Module parent, boolean defaultVal) { super(name, parent); this.enabled = defaultVal; }
}
