package com.nyxsoft;

import com.nyxsoft.modules.*;
import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public List<Module> list = new ArrayList<>();

    public ModuleManager() {
        list.add(new Interface());
        list.add(new KillAura());
        list.add(new AimAssist());
        list.add(new TriggerBot());
        list.add(new Velocity());
        list.add(new AutoGapple());
        list.add(new AutoSword());
        list.add(new MaceHelper());
        list.add(new Flight());
        list.add(new NoSlow());
        list.add(new PlayerESP());
        list.add(new EntityESP());
        list.add(new WardenESP());
        list.add(new SandiqESP());
        list.add(new Metka());
        list.add(new Fullbright());
        list.add(new FpsBoost());
        list.add(new ChinaHat());
        list.add(new DeathCoords());
        list.add(new KillEffect());
        list.add(new ServerHelper());
        list.add(new AutoSpam());
        list.add(new Bot());
    }

    public Module get(String name) {
        for (Module m : list) {
            if (m.name.equalsIgnoreCase(name) ||
                m.getClass().getSimpleName().equalsIgnoreCase(name)) return m;
        }
        return null;
    }
    public void onTick() { for (Module m : list) if (m.enabled) m.onTick(); }
}
