# NyxSoft — Minecraft 1.21.4 Fabric

A source project assembled from the Java files provided in the conversation.

## Build
- Java 21
- Gradle (Fabric Loom 1.9-SNAPSHOT)
- Minecraft 1.21.4
- Fabric Loader 0.16.9
- Fabric API 0.119.2+1.21.4

Run `gradle build` (or use a Gradle wrapper if you add one).

## Important
This archive contains the supplied source code. It has **not been compiled or tested**.
Some Minecraft/Yarn API calls and mixin signatures may need adjustment for 1.21.4.
The module implementations were retained from the submitted snippets; review them
before using the mod, especially automation, movement, and chat features.
